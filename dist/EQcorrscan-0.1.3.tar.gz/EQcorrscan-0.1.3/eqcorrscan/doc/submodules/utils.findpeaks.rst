findpeaks
----------

.. currentmodule:: eqcorrscan.utils.findpeaks
.. automodule:: eqcorrscan.utils.findpeaks

    .. comment to end block

    Classes & Functions
    -------------------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       find_peaks2_short
       find_peaks_dep

    .. comment to end block
