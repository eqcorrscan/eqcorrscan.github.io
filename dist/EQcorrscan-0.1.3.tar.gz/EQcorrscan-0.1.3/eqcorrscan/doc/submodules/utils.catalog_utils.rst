catalog_utils
-------------

.. currentmodule:: eqcorrscan.utils.catalog_utils
.. automodule:: eqcorrscan.utils.catalog_utils

    .. comment to end block

    Classes & Functions
    -------------------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       filter_picks

    .. comment to end block
