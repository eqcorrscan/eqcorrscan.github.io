eqcorrscan.core.subspace.Detector
=================================

.. currentmodule:: eqcorrscan.core.subspace

.. autoclass:: Detector

   .. rubric:: Methods

   .. autosummary::

      construct
      detect
      energy_capture
      partition
      read
      write


   .. automethod:: __init__
   .. automethod:: construct
   .. automethod:: detect
   .. automethod:: energy_capture
   .. automethod:: partition
   .. automethod:: read
   .. automethod:: write

