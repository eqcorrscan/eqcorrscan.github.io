subspace
--------

.. currentmodule:: eqcorrscan.core.subspace
.. automodule:: eqcorrscan.core.subspace

    .. comment to end block

    Classes
    -------
    .. toctree::
        :maxdepth: 1

        core.subspace.Detector

    Functions
    ---------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       read_detector
       multi
       subspace_detect

    .. comment to end block
