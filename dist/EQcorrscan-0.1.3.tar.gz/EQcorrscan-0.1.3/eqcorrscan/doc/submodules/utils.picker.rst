picker
------

.. currentmodule:: eqcorrscan.utils.picker
.. automodule:: eqcorrscan.utils.picker

    .. comment to end block

    Classes & Functions
    -------------------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       cross_net
       stalta_pick

    .. comment to end block
