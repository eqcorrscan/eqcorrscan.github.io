parameters
----------

.. currentmodule:: eqcorrscan.utils.parameters
.. automodule:: eqcorrscan.utils.parameters

    .. comment to end block

    Classes & Functions
    -------------------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       EQcorrscanParameters
       read_parameters

    .. comment to end block
