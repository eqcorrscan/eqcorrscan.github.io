trigger
-------

.. currentmodule:: eqcorrscan.utils.trigger
.. automodule:: eqcorrscan.utils.trigger

    .. comment to end block

    Classes & Functions
    -------------------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       network_trigger
       read_trigger_parameters
       TriggerParameters

    .. comment to end block