catalog_to_dd
-------------

.. currentmodule:: eqcorrscan.utils.catalog_to_dd
.. automodule:: eqcorrscan.utils.catalog_to_dd

    .. comment to end block

    Classes & Functions
    -------------------
    .. autosummary::
       :toctree: autogen
       :nosignatures:

       readSTATION0
       read_phase
       sfiles_to_event
       write_catalog
       write_correlations
       write_event

    .. comment to end block
