eqcorrscan.utils.picker.stalta_pick
===================================

.. currentmodule:: eqcorrscan.utils.picker

.. autofunction:: stalta_pick