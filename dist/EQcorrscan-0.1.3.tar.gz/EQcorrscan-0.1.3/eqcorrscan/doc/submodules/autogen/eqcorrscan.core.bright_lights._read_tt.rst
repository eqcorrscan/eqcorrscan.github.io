eqcorrscan.core.bright_lights._read_tt
======================================

.. currentmodule:: eqcorrscan.core.bright_lights

.. autofunction:: _read_tt