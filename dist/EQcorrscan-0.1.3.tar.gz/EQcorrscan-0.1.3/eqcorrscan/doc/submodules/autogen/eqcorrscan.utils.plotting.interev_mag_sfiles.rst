eqcorrscan.utils.plotting.interev_mag_sfiles
============================================

.. currentmodule:: eqcorrscan.utils.plotting

.. autofunction:: interev_mag_sfiles