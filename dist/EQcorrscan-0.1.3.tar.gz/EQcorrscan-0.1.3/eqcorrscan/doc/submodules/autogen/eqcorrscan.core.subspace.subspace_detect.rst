eqcorrscan.core.subspace.subspace_detect
========================================

.. currentmodule:: eqcorrscan.core.subspace

.. autofunction:: subspace_detect