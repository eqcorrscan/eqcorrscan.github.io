eqcorrscan.core.template_gen.multi_template_gen
===============================================

.. currentmodule:: eqcorrscan.core.template_gen

.. autofunction:: multi_template_gen