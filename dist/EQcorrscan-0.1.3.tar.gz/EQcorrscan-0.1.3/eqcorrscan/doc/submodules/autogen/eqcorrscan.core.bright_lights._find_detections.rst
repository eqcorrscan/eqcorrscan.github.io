eqcorrscan.core.bright_lights._find_detections
==============================================

.. currentmodule:: eqcorrscan.core.bright_lights

.. autofunction:: _find_detections