eqcorrscan.core.match_filter.read_detections
============================================

.. currentmodule:: eqcorrscan.core.match_filter

.. autofunction:: read_detections