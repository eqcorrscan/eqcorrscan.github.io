eqcorrscan.utils.catalog_to_dd.write_catalog
============================================

.. currentmodule:: eqcorrscan.utils.catalog_to_dd

.. autofunction:: write_catalog