eqcorrscan.utils.findpeaks.find_peaks_dep
=========================================

.. currentmodule:: eqcorrscan.utils.findpeaks

.. autofunction:: find_peaks_dep