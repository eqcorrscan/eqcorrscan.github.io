eqcorrscan.utils.sfile_util.eventtosfile
========================================

.. currentmodule:: eqcorrscan.utils.sfile_util

.. autofunction:: eventtosfile