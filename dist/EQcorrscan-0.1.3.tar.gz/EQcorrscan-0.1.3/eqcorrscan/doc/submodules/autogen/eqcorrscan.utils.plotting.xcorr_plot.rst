eqcorrscan.utils.plotting.xcorr_plot
====================================

.. currentmodule:: eqcorrscan.utils.plotting

.. autofunction:: xcorr_plot