eqcorrscan.utils.archive_read._check_available_data
===================================================

.. currentmodule:: eqcorrscan.utils.archive_read

.. autofunction:: _check_available_data