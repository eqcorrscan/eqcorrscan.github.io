eqcorrscan.utils.seismo_logs.rt_location_log
============================================

.. currentmodule:: eqcorrscan.utils.seismo_logs

.. autofunction:: rt_location_log