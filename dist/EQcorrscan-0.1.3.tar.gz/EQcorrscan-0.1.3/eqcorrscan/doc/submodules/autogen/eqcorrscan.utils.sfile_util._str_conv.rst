eqcorrscan.utils.sfile_util._str_conv
=====================================

.. currentmodule:: eqcorrscan.utils.sfile_util

.. autofunction:: _str_conv