eqcorrscan.utils.trigger.read_trigger_parameters
================================================

.. currentmodule:: eqcorrscan.utils.trigger

.. autofunction:: read_trigger_parameters