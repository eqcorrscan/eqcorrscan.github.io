eqcorrscan.utils.mag_calc.SVD_moments
=====================================

.. currentmodule:: eqcorrscan.utils.mag_calc

.. autofunction:: SVD_moments