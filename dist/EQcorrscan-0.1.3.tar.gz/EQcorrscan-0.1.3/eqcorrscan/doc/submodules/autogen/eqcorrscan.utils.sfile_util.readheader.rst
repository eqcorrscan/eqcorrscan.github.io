eqcorrscan.utils.sfile_util.readheader
======================================

.. currentmodule:: eqcorrscan.utils.sfile_util

.. autofunction:: readheader