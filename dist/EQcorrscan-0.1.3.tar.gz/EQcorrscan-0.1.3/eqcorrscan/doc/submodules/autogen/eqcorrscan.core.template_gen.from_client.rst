eqcorrscan.core.template_gen.from_client
========================================

.. currentmodule:: eqcorrscan.core.template_gen

.. autofunction:: from_client