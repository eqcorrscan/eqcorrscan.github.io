eqcorrscan.utils.mag_calc.calc_max_curv
=======================================

.. currentmodule:: eqcorrscan.utils.mag_calc

.. autofunction:: calc_max_curv