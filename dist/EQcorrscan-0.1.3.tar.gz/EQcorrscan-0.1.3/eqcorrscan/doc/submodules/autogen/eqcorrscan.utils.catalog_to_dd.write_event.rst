eqcorrscan.utils.catalog_to_dd.write_event
==========================================

.. currentmodule:: eqcorrscan.utils.catalog_to_dd

.. autofunction:: write_event