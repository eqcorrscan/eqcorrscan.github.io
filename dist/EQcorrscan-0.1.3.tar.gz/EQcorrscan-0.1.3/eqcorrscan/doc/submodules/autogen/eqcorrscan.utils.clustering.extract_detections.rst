eqcorrscan.utils.clustering.extract_detections
==============================================

.. currentmodule:: eqcorrscan.utils.clustering

.. autofunction:: extract_detections