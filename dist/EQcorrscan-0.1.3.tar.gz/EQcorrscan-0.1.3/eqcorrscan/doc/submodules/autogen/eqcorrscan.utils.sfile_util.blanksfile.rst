eqcorrscan.utils.sfile_util.blanksfile
======================================

.. currentmodule:: eqcorrscan.utils.sfile_util

.. autofunction:: blanksfile