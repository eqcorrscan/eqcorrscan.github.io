eqcorrscan.utils.catalog_to_dd.readSTATION0
===========================================

.. currentmodule:: eqcorrscan.utils.catalog_to_dd

.. autofunction:: readSTATION0