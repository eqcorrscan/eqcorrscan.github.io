eqcorrscan.utils.plotting.cumulative_detections
===============================================

.. currentmodule:: eqcorrscan.utils.plotting

.. autofunction:: cumulative_detections