eqcorrscan.core.subspace.multi
==============================

.. currentmodule:: eqcorrscan.core.subspace

.. autofunction:: multi