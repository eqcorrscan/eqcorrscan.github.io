eqcorrscan.core.lag_calc._day_loop
==================================

.. currentmodule:: eqcorrscan.core.lag_calc

.. autofunction:: _day_loop