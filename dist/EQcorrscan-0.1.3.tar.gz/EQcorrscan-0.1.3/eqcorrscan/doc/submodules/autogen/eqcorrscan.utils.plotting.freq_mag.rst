eqcorrscan.utils.plotting.freq_mag
==================================

.. currentmodule:: eqcorrscan.utils.plotting

.. autofunction:: freq_mag