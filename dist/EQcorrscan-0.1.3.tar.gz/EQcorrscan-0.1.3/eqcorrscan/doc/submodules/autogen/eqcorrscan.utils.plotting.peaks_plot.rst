eqcorrscan.utils.plotting.peaks_plot
====================================

.. currentmodule:: eqcorrscan.utils.plotting

.. autofunction:: peaks_plot