eqcorrscan.core.match_filter.detections_to_catalog
==================================================

.. currentmodule:: eqcorrscan.core.match_filter

.. autofunction:: detections_to_catalog