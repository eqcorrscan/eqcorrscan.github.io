eqcorrscan.utils.pre_processing.dayproc
=======================================

.. currentmodule:: eqcorrscan.utils.pre_processing

.. autofunction:: dayproc