eqcorrscan.utils.catalog_to_dd.write_correlations
=================================================

.. currentmodule:: eqcorrscan.utils.catalog_to_dd

.. autofunction:: write_correlations