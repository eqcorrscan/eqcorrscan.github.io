eqcorrscan.utils.mag_calc.calc_b_value
======================================

.. currentmodule:: eqcorrscan.utils.mag_calc

.. autofunction:: calc_b_value