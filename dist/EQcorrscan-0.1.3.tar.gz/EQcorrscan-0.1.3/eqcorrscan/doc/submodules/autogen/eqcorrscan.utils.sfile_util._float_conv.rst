eqcorrscan.utils.sfile_util._float_conv
=======================================

.. currentmodule:: eqcorrscan.utils.sfile_util

.. autofunction:: _float_conv