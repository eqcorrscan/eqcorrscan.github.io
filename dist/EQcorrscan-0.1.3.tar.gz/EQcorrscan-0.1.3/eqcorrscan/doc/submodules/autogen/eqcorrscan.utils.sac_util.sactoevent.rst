eqcorrscan.utils.sac_util.sactoevent
====================================

.. currentmodule:: eqcorrscan.utils.sac_util

.. autofunction:: sactoevent