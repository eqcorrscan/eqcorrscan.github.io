eqcorrscan.utils.picker.cross_net
=================================

.. currentmodule:: eqcorrscan.utils.picker

.. autofunction:: cross_net