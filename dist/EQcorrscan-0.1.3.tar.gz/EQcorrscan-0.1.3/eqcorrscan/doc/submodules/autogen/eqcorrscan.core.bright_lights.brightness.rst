eqcorrscan.core.bright_lights.brightness
========================================

.. currentmodule:: eqcorrscan.core.bright_lights

.. autofunction:: brightness