eqcorrscan.utils.archive_read._get_station_file
===============================================

.. currentmodule:: eqcorrscan.utils.archive_read

.. autofunction:: _get_station_file