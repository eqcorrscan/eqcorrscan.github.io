eqcorrscan.utils.plotting.chunk_data
====================================

.. currentmodule:: eqcorrscan.utils.plotting

.. autofunction:: chunk_data