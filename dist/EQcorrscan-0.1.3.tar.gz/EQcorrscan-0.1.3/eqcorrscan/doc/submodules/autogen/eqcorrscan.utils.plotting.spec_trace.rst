eqcorrscan.utils.plotting.spec_trace
====================================

.. currentmodule:: eqcorrscan.utils.plotting

.. autofunction:: spec_trace