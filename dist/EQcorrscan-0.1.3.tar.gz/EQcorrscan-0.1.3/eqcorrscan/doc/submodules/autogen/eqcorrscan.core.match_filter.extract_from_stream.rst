eqcorrscan.core.match_filter.extract_from_stream
================================================

.. currentmodule:: eqcorrscan.core.match_filter

.. autofunction:: extract_from_stream