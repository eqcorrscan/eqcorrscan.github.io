eqcorrscan.utils.mag_calc.amp_pick_event
========================================

.. currentmodule:: eqcorrscan.utils.mag_calc

.. autofunction:: amp_pick_event