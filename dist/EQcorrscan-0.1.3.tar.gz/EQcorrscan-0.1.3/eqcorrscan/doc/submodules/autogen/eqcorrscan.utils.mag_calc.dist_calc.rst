eqcorrscan.utils.mag_calc.dist_calc
===================================

.. currentmodule:: eqcorrscan.utils.mag_calc

.. autofunction:: dist_calc