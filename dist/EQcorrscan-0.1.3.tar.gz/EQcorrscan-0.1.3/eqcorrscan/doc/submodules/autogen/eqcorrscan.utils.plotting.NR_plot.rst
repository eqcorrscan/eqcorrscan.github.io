eqcorrscan.utils.plotting.NR_plot
=================================

.. currentmodule:: eqcorrscan.utils.plotting

.. autofunction:: NR_plot