eqcorrscan.utils.catalog_to_dd.read_phase
=========================================

.. currentmodule:: eqcorrscan.utils.catalog_to_dd

.. autofunction:: read_phase