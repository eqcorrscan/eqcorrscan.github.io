eqcorrscan.utils.sfile_util.nordpick
====================================

.. currentmodule:: eqcorrscan.utils.sfile_util

.. autofunction:: nordpick