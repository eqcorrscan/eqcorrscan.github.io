eqcorrscan.utils.despike.template_remove
========================================

.. currentmodule:: eqcorrscan.utils.despike

.. autofunction:: template_remove