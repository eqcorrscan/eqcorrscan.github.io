eqcorrscan.utils.synth_seis.template_grid
=========================================

.. currentmodule:: eqcorrscan.utils.synth_seis

.. autofunction:: template_grid