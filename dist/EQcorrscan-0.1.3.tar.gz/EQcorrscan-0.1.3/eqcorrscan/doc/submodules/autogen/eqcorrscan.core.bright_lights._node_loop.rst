eqcorrscan.core.bright_lights._node_loop
========================================

.. currentmodule:: eqcorrscan.core.bright_lights

.. autofunction:: _node_loop