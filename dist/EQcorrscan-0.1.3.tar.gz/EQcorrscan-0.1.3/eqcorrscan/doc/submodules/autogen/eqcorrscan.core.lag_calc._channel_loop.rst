eqcorrscan.core.lag_calc._channel_loop
======================================

.. currentmodule:: eqcorrscan.core.lag_calc

.. autofunction:: _channel_loop