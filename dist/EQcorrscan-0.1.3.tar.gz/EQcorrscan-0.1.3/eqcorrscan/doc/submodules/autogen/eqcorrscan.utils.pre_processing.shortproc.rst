eqcorrscan.utils.pre_processing.shortproc
=========================================

.. currentmodule:: eqcorrscan.utils.pre_processing

.. autofunction:: shortproc