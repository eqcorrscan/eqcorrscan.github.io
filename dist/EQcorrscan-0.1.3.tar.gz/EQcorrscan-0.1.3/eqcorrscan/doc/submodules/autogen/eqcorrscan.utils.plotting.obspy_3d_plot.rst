eqcorrscan.utils.plotting.obspy_3d_plot
=======================================

.. currentmodule:: eqcorrscan.utils.plotting

.. autofunction:: obspy_3d_plot