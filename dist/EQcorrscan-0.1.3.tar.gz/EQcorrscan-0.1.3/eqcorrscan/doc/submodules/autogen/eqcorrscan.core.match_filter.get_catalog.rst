eqcorrscan.core.match_filter.get_catalog
========================================

.. currentmodule:: eqcorrscan.core.match_filter

.. autofunction:: get_catalog