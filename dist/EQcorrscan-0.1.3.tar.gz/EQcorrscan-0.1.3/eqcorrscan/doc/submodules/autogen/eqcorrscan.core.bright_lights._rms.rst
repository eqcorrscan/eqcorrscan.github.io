eqcorrscan.core.bright_lights._rms
==================================

.. currentmodule:: eqcorrscan.core.bright_lights

.. autofunction:: _rms