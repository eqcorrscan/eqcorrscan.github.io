eqcorrscan.utils.sfile_util._nortoevmag
=======================================

.. currentmodule:: eqcorrscan.utils.sfile_util

.. autofunction:: _nortoevmag