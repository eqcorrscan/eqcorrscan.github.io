eqcorrscan.utils.mag_calc._max_p2t
==================================

.. currentmodule:: eqcorrscan.utils.mag_calc

.. autofunction:: _max_p2t