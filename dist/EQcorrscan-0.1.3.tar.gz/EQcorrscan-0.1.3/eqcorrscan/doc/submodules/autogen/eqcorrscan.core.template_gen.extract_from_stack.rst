eqcorrscan.core.template_gen.extract_from_stack
===============================================

.. currentmodule:: eqcorrscan.core.template_gen

.. autofunction:: extract_from_stack