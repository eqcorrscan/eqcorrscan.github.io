eqcorrscan.utils.plotting.pretty_template_plot
==============================================

.. currentmodule:: eqcorrscan.utils.plotting

.. autofunction:: pretty_template_plot