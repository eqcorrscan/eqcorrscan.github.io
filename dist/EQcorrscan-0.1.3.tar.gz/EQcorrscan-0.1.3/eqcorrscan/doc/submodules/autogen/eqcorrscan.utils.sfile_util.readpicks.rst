eqcorrscan.utils.sfile_util.readpicks
=====================================

.. currentmodule:: eqcorrscan.utils.sfile_util

.. autofunction:: readpicks