eqcorrscan.utils.mag_calc._pairwise
===================================

.. currentmodule:: eqcorrscan.utils.mag_calc

.. autofunction:: _pairwise