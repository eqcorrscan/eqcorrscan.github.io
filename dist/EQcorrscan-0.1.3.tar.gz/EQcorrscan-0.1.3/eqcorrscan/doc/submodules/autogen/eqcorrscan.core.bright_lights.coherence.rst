eqcorrscan.core.bright_lights.coherence
=======================================

.. currentmodule:: eqcorrscan.core.bright_lights

.. autofunction:: coherence