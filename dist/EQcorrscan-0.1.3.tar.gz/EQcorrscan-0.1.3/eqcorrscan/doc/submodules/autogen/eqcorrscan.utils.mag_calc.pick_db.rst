eqcorrscan.utils.mag_calc.pick_db
=================================

.. currentmodule:: eqcorrscan.utils.mag_calc

.. autofunction:: pick_db