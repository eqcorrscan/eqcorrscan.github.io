eqcorrscan.utils.catalog_utils.filter_picks
===========================================

.. currentmodule:: eqcorrscan.utils.catalog_utils

.. autofunction:: filter_picks