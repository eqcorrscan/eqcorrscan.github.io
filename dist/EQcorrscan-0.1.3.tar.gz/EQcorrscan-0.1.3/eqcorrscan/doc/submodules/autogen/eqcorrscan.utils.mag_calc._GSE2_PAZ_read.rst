eqcorrscan.utils.mag_calc._GSE2_PAZ_read
========================================

.. currentmodule:: eqcorrscan.utils.mag_calc

.. autofunction:: _GSE2_PAZ_read