eqcorrscan.utils.trigger.network_trigger
========================================

.. currentmodule:: eqcorrscan.utils.trigger

.. autofunction:: network_trigger