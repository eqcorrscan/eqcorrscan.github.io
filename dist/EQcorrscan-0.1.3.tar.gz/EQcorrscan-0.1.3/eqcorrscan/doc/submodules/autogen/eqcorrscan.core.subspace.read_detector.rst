eqcorrscan.core.subspace.read_detector
======================================

.. currentmodule:: eqcorrscan.core.subspace

.. autofunction:: read_detector