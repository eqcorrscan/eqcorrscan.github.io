eqcorrscan.utils.seismo_logs.rt_time_log
========================================

.. currentmodule:: eqcorrscan.utils.seismo_logs

.. autofunction:: rt_time_log