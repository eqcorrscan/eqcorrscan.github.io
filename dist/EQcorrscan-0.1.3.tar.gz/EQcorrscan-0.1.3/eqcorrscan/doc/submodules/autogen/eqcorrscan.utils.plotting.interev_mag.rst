eqcorrscan.utils.plotting.interev_mag
=====================================

.. currentmodule:: eqcorrscan.utils.plotting

.. autofunction:: interev_mag