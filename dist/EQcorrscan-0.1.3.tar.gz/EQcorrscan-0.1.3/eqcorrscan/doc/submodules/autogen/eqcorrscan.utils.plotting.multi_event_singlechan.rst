eqcorrscan.utils.plotting.multi_event_singlechan
================================================

.. currentmodule:: eqcorrscan.utils.plotting

.. autofunction:: multi_event_singlechan