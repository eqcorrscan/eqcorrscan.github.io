eqcorrscan.utils.mag_calc._sim_WA
=================================

.. currentmodule:: eqcorrscan.utils.mag_calc

.. autofunction:: _sim_WA