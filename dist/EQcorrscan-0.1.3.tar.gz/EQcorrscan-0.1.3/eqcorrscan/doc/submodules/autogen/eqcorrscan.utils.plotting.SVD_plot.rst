eqcorrscan.utils.plotting.SVD_plot
==================================

.. currentmodule:: eqcorrscan.utils.plotting

.. autofunction:: SVD_plot