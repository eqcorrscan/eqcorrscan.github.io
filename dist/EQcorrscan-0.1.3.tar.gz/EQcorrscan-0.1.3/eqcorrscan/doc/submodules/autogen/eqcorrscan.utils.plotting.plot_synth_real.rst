eqcorrscan.utils.plotting.plot_synth_real
=========================================

.. currentmodule:: eqcorrscan.utils.plotting

.. autofunction:: plot_synth_real