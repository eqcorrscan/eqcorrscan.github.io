eqcorrscan.core.template_gen.from_meta_file
===========================================

.. currentmodule:: eqcorrscan.core.template_gen

.. autofunction:: from_meta_file