eqcorrscan.core.bright_lights._resample_grid
============================================

.. currentmodule:: eqcorrscan.core.bright_lights

.. autofunction:: _resample_grid