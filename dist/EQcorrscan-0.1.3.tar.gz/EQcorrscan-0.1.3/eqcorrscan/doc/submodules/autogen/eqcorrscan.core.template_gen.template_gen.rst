eqcorrscan.core.template_gen.template_gen
=========================================

.. currentmodule:: eqcorrscan.core.template_gen

.. autofunction:: template_gen