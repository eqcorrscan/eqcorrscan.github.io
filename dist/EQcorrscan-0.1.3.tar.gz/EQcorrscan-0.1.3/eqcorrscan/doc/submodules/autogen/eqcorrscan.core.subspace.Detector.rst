eqcorrscan.core.subspace.Detector
=================================

.. currentmodule:: eqcorrscan.core.subspace

.. autoclass:: Detector

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Detector.__init__
      ~Detector.construct
      ~Detector.detect
      ~Detector.energy_capture
      ~Detector.partition
      ~Detector.read
      ~Detector.write
   
   

   
   
   