eqcorrscan.utils.synth_seis.SVD_sim
===================================

.. currentmodule:: eqcorrscan.utils.synth_seis

.. autofunction:: SVD_sim