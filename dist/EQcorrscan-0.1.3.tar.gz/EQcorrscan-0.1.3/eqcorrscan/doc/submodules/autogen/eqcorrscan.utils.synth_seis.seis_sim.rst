eqcorrscan.utils.synth_seis.seis_sim
====================================

.. currentmodule:: eqcorrscan.utils.synth_seis

.. autofunction:: seis_sim