eqcorrscan.utils.parameters.read_parameters
===========================================

.. currentmodule:: eqcorrscan.utils.parameters

.. autofunction:: read_parameters