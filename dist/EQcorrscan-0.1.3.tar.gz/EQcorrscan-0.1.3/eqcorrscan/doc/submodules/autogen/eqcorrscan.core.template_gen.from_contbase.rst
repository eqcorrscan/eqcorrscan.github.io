eqcorrscan.core.template_gen.from_contbase
==========================================

.. currentmodule:: eqcorrscan.core.template_gen

.. autofunction:: from_contbase