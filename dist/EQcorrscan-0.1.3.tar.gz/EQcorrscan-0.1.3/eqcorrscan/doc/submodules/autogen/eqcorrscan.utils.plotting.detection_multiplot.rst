eqcorrscan.utils.plotting.detection_multiplot
=============================================

.. currentmodule:: eqcorrscan.utils.plotting

.. autofunction:: detection_multiplot