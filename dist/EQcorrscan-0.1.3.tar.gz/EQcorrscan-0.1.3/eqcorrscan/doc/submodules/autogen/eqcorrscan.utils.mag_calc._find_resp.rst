eqcorrscan.utils.mag_calc._find_resp
====================================

.. currentmodule:: eqcorrscan.utils.mag_calc

.. autofunction:: _find_resp