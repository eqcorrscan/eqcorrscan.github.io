eqcorrscan.utils.despike.median_filter
======================================

.. currentmodule:: eqcorrscan.utils.despike

.. autofunction:: median_filter