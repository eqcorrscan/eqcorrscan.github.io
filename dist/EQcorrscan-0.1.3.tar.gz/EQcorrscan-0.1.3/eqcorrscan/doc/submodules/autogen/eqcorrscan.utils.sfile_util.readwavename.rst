eqcorrscan.utils.sfile_util.readwavename
========================================

.. currentmodule:: eqcorrscan.utils.sfile_util

.. autofunction:: readwavename