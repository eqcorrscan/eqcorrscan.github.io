eqcorrscan.utils.catalog_to_dd.sfiles_to_event
==============================================

.. currentmodule:: eqcorrscan.utils.catalog_to_dd

.. autofunction:: sfiles_to_event