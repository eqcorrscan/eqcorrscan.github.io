eqcorrscan.utils.sfile_util._evmagtonor
=======================================

.. currentmodule:: eqcorrscan.utils.sfile_util

.. autofunction:: _evmagtonor