eqcorrscan.utils.synth_seis.generate_synth_data
===============================================

.. currentmodule:: eqcorrscan.utils.synth_seis

.. autofunction:: generate_synth_data