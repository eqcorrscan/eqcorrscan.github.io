eqcorrscan.core.template_gen.from_seishub
=========================================

.. currentmodule:: eqcorrscan.core.template_gen

.. autofunction:: from_seishub