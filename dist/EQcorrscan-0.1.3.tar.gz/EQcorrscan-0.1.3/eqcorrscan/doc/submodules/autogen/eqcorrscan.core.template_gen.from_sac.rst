eqcorrscan.core.template_gen.from_sac
=====================================

.. currentmodule:: eqcorrscan.core.template_gen

.. autofunction:: from_sac