eqcorrscan.core.match_filter.DETECTION
======================================

.. currentmodule:: eqcorrscan.core.match_filter

.. autoclass:: DETECTION

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~DETECTION.__init__
      ~DETECTION.write
   
   

   
   
   