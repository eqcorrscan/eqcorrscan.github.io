eqcorrscan.core.match_filter.match_filter
=========================================

.. currentmodule:: eqcorrscan.core.match_filter

.. autofunction:: match_filter