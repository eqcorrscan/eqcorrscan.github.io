eqcorrscan.utils.sfile_util.stationtoseisan
===========================================

.. currentmodule:: eqcorrscan.utils.sfile_util

.. autofunction:: stationtoseisan