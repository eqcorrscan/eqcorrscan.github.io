eqcorrscan.utils.sfile_util.populatesfile
=========================================

.. currentmodule:: eqcorrscan.utils.sfile_util

.. autofunction:: populatesfile