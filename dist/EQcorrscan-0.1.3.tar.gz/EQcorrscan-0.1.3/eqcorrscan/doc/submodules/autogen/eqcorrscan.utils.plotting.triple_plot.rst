eqcorrscan.utils.plotting.triple_plot
=====================================

.. currentmodule:: eqcorrscan.utils.plotting

.. autofunction:: triple_plot