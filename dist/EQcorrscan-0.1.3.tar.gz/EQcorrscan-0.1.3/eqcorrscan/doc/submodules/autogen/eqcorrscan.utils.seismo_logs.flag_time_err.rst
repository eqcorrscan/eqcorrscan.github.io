eqcorrscan.utils.seismo_logs.flag_time_err
==========================================

.. currentmodule:: eqcorrscan.utils.seismo_logs

.. autofunction:: flag_time_err