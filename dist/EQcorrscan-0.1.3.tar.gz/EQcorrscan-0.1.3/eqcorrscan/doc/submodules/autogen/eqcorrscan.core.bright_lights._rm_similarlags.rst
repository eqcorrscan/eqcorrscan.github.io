eqcorrscan.core.bright_lights._rm_similarlags
=============================================

.. currentmodule:: eqcorrscan.core.bright_lights

.. autofunction:: _rm_similarlags