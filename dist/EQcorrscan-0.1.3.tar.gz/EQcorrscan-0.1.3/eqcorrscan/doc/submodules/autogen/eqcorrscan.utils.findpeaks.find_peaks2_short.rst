eqcorrscan.utils.findpeaks.find_peaks2_short
============================================

.. currentmodule:: eqcorrscan.utils.findpeaks

.. autofunction:: find_peaks2_short