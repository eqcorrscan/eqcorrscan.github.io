eqcorrscan.core.match_filter._template_loop
===========================================

.. currentmodule:: eqcorrscan.core.match_filter

.. autofunction:: _template_loop