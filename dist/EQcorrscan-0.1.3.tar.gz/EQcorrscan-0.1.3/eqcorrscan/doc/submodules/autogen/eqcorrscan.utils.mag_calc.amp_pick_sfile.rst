eqcorrscan.utils.mag_calc.amp_pick_sfile
========================================

.. currentmodule:: eqcorrscan.utils.mag_calc

.. autofunction:: amp_pick_sfile