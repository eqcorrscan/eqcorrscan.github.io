eqcorrscan.utils.archive_read.read_data
=======================================

.. currentmodule:: eqcorrscan.utils.archive_read

.. autofunction:: read_data