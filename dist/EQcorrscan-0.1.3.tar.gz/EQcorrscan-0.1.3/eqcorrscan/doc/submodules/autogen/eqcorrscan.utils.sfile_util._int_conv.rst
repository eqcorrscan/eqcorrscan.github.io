eqcorrscan.utils.sfile_util._int_conv
=====================================

.. currentmodule:: eqcorrscan.utils.sfile_util

.. autofunction:: _int_conv