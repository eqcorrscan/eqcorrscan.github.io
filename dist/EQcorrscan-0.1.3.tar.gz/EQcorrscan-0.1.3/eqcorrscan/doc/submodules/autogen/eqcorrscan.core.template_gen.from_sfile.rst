eqcorrscan.core.template_gen.from_sfile
=======================================

.. currentmodule:: eqcorrscan.core.template_gen

.. autofunction:: from_sfile