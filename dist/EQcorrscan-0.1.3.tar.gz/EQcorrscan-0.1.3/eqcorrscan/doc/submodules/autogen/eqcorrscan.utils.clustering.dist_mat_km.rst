eqcorrscan.utils.clustering.dist_mat_km
=======================================

.. currentmodule:: eqcorrscan.utils.clustering

.. autofunction:: dist_mat_km