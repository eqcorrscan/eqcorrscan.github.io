eqcorrscan.core.match_filter.normxcorr2
=======================================

.. currentmodule:: eqcorrscan.core.match_filter

.. autofunction:: normxcorr2