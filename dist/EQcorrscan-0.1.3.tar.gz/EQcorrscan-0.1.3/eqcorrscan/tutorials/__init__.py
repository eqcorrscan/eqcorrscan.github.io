if __name__ == '__main__':
    import doctest
    doctest.testmod(exclude_empty=True)
